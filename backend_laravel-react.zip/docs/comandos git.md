Descargar e Instalar GIT 
    https://git-scm.com/download/win
2. Configurar GIT en nuestro equipo
    git config --global user.name su_nombre
    git config --global user.email sucorreo@mail.com
...................................................
Crear una cuenta en (GITHUB, BITBUCKET, GITLAB)
    - creacion de nuevo repositorio

...................................................
git clone direccion
---------------------------------------------------
git init
git remote add origin https://github.com/cchura94/backend_laravel-react.git
---------------------------------------------------
git add .
git commit -m "mensaje"
git push origin master
---------------------------------------------------
git pull origin master